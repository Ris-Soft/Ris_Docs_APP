<?php
//引入配置项
include './assets/function.php';
?>
<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Language" content="zh-CN">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        <?php echo $pageName . ' - ' . $WebName ?>
    </title>
    <script>
        let defaultTitle = '<?php echo $WebName ?>';
        let defaultNavItems = [];
        let defaultNavRightItems = [{
            "text": "<i class=\"bi bi-info-circle\"></i>",
            "href": `javascript:createDialog(\"alert\", \"primary\", \"关于<?php echo addslashes($WebName) ?>\", \"<?php echo $copyRight ? str_replace('"',"'",htmlspecialchars_decode($copyRight)) . '<br>' : '' ?>软件版本：<?php echo $localVersion; ?><br><a href=\\\"https://docs.3r60.top/Project\\\">Ris_Docs</a>提供软件服务\")`
        }];
        let defaultFooterLinks = [];
        let defaultCopyright = `<?php echo $copyRight ? htmlspecialchars_decode($copyRight) : '版权所有 © 2024 腾瑞思智' ?>`;
        let webTitle = '<?php echo addslashes($WebName) ?? '瑞思文档' ?>';
    </script>
    <script src="https://assets.3r60.top/v3/package.js"></script>
    <link rel="stylesheet" href="https://assets.3r60.top/other/editormd/css/editormd.css" />
    <link rel="stylesheet" href="<?php echo $Rewrite ? '//' . $Http_Host_RW . '/assets/style.css' : './assets/style.css' ?>">
</head>

<body>
    <topbar data-homeUrl='<?php echo ($Rewrite == "true") ? '//' . $Http_Host_RW : '.' ?>' data-showExpendButton='false' data-loadCallBack='refreshMarkdownContent'>
    </topbar>
    <main class="flex pb-0">
        <lead>
            <ul class="list" data-loadFromFile='false' data-changeTitle='false'>
                <?php loadDirectory("common"); ?>
            </ul>
            <footer></footer>
        </lead>
        <!--主要部分-->
        <content class="markdown-body" style="padding-top:6px">
            <?php includePlugin('user'); ?>
            <span class='pagePath'>
                <?php
                echo $WebName . '>' . $pageName ?>&nbsp;&nbsp;&nbsp;
                <span id="toolBox">
                    <a href="javascript:startPrint();" class="colorNoToggle">
                        <i class="bi bi-printer colorNoToggle" style="font-size:15px;"></i>
                        打印模式</a>&nbsp;&nbsp;
                    <a href="javascript:copyUrl(window.location.href)">
                        <i class="bi bi-clipboard colorNoToggle" style="font-size:15px;"></i>
                        复制链接</a>
                </span>
            </span>
            <div style="margin-top:10px" id="test-editormd-view">
                <textarea style="display:none" name="test-editormd-markdown-doc">
			   <?php if (empty($_GET['article']) || $_GET['article'] === 'home') {
                    loadArticle('home');
                } else {
                    loadArticle($_GET['article']);
                } ?>
			   </textarea>
            </div>
        </content>
    </main>
    <script>
        $(document).ready(function() {
            $('.list a').on('click', function(event) {
                event.preventDefault();
                history.pushState('', '', this.href);
                fetchAndReplaceContent(this.href, 'title,content', 'title,content', () => {
                    refreshMarkdownContent();
                    setActiveLinkInList($('.list'));
                });
            });
            setTimeout(() => {
                $('a[href="./"]').attr('href', '<?php echo $_SERVER['DOCUMENT_ROOT'] ?>')
                addButtonToNavRight('bi bi-pen', null, "#", () => {
                    window.location.href = '<?php echo $Rewrite ? '//' . $Http_Host_RW . '/admin.php' : './admin.php' ?>'
                });
            }, 1000)
        });
    </script>
    <script src="https://assets.3r60.top/other/editormd/lib/marked.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/marked.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/prettify.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/raphael.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/underscore.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/sequence-diagram.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/flowchart.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/lib/jquery.flowchart.min.js"></script>
    <script src="https://assets.3r60.top/other/editormd/editormd.js"></script>
    <script type="text/javascript">
        $(function() {
            testEditormdView = editormd.markdownToHTML("test-editormd-view", {
                htmlDecode: true,
                toc: true,
                tocm: true,
                emoji: true,
                taskList: true,
                tex: true, // 默认不解析
                flowChart: true, // 默认不解析
                sequenceDiagram: true, // 默认不解析
            });
            if (getColorMode()) {
                $('#test-editormd-view').addClass('editormd-preview-theme-dark');
            } else {
                $('#test-editormd-view').removeClass('editormd-preview-theme-dark');
            }
            $(document).on('colorModeChanged', function(event, colorMode) {
                if (testEditormdView !== null) {
                    if (colorMode == 'dark') {
                        $('#test-editormd-view').addClass('editormd-preview-theme-dark');
                    } else {
                        $('#test-editormd-view').removeClass('editormd-preview-theme-dark');
                    }
                }
            });
            window.scrollTo({
                top: document.querySelector(location.hash).offsetTop - 60,
                behavior: 'smooth'
            });
        });
    </script>
    <script>
        function copyUrl(id) {
            $("body").after("<input id='copyVal'></input>");
            var text = id;
            var input = document.getElementById("copyVal");
            input.value = text;
            input.select();
            input.setSelectionRange(0, input.value.length);
            document.execCommand("copy");
            $("#copyVal").remove();
            createMessage('复制链接成功', 'success');
        }

        function startPrint() {
            $("#toolBox").css('display', 'none');
            $("lead").remove();
            $("topbar").remove();
            $('.pagePath').css('marginLeft', '0px');
            $("content").css('marginTop', '0px');
            $("content").css('marginLeft', '0px');
            $("main").css('padding', '0px');
            if (getCookie('set_colorMode') === 'dark') {
                colorMode('light', false);
            }
            print();
        }

        function refreshMarkdownContent() {
            testEditormdView = editormd.markdownToHTML("test-editormd-view", {
                htmlDecode: true,
                toc: true,
                tocm: true,
                emoji: true,
                htmlDecode: true,
                taskList: true,
                tex: true,
                flowChart: true,
                sequenceDiagram: true,
            });
            if (getColorMode()) {
                $('#test-editormd-view').addClass('editormd-preview-theme-dark');
            } else {
                $('#test-editormd-view').removeClass('editormd-preview-theme-dark');
            }
            setTimeout(() => {
                $('a[href="./"]').attr('href', '<?php echo ($Rewrite == "true") ? '//' . $Http_Host_RW : '.' ?>')
            }, 5000)

        }
    </script>
</body>

</html>