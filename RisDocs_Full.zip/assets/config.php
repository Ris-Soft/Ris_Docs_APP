<?php
$AdminPassword = '$2y$10$uZQgW9pQziw4K8nXp4EcWOIEn1JEEtlF7fi8FKVA0mp/ZWANUSJV2';
$WebName = '瑞思文档';
$Rewrite = '';
$SecurityEntrance = '';
$copyRight = '版权所有 © 2025 腾瑞思智';
