<?php
$AdminPassword = '$2y$10$2/DE8Nc73uYTIYFqh/zFdO50mE8Yf1idqu1dO99GZF27.4TKdcQRe';
$WebName = '瑞思文档';
$Rewrite = '';
$SecurityEntrance = '';
$copyRight = '版权所有 © 2024 腾瑞思智';
